import React, { Fragment } from 'react'
import Button from '../button'
import styles from "./style.module.css"

const SectionHeader = ({title,Btntext="VIEW ALL"}) => {
  return (
    <Fragment>
        
        <div className={styles.section_header}>
            <h5>
            {title}
            </h5>
            <Button text={Btntext} type={"text"} showArrow={true} />
        </div>
    </Fragment>
  )
}

export default SectionHeader