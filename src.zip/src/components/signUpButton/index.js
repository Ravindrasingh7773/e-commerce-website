import React from "react";
import styles from "./style.module.css";    
import SignUpIcon from "../../icons/signUpIcon";

const SignUpButton = ({onClick}) => {
  return (
    <div className={styles.round_button} onClick={onClick}>
      <SignUpIcon />
    </div>
  );
};

export default SignUpButton;
