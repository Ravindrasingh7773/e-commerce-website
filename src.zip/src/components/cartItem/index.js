import React from 'react'
import styles from "./style.module.css"
import CloseIcon from '../../icons/closeIcon'
import Image from "../../assets/images/item1.png"

const CartItem = ({Image,Name,price,quantity}) => {
  console.log(price)
const handleTotal = () =>{
  return price * quantity;
 
}

  return (
    <div className={styles.cart_item}>
     <div className={styles.cart_item_image}>
        <img src={Image}  alt="Product Image" />
     </div>
     <div className={styles.cart_item_details}>
        <div className={styles.cd_first}>
            <h5>{Name}</h5>
            <h5>${price}</h5>
        </div>
        <div className={`${styles.cd_second} ${styles.cd_first}`}>
            <h5>${handleTotal}</h5>
            <div><CloseIcon /></div>
        </div> 
        <div className={styles.cd_quanity}>
            <button>-</button>
            <input type="number" value={quantity} />
            <button>+</button>
        </div>
     </div>
    </div>
  )
}

export default CartItem