 
import React, { Fragment, useState, useRef } from "react";
import styles from "./style.module.css"; 
import DownArrowIcon from "../../icons/downArrowIcon";
import UpArrowIcon from "../../icons/upArrowIcon";

const Select = ({ options, keyName, placeholder, defaultValue, onSelect, Icon }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState(defaultValue || null);
 
  const selectRef = useRef(null);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleChange = (option) => {
    setSelectedOption(option);
    onSelect(option);
    setIsOpen(false);
  };

  const handleFocus = () => { 
    setIsOpen(true);
  };

  const handleBlur = (event) => { 
    if (!selectRef.current.contains(event.relatedTarget)) {
      setIsOpen(false);
    }
  };

  return (
    <Fragment>
      <div
        className={styles.custom_select}
        tabIndex={0} 
        onFocus={handleFocus}
        onBlur={handleBlur}
        ref={selectRef}
      >
        <div className={styles.cs_label} onClick={handleToggle}>
          {Icon}
          {selectedOption ? selectedOption[keyName] : placeholder}
          {isOpen ? <UpArrowIcon /> : <DownArrowIcon />}
        </div>
        {isOpen && (
          <div className={styles.cs_options}>
            {options.map((option, i) => (
              <div
                key={i}
                className={styles.cs_option}
                tabIndex={0} 
                onClick={() => handleChange(option)}
              >
                {option[keyName]}
              </div>
            ))}
          </div>
        )}
      </div>
    </Fragment>
  );
};

export default Select;
