import React, { Fragment } from 'react'
import Section from '../../components/section'
import styles from "./style.module.css"
import { Col, Container, Row } from 'react-bootstrap'
import HeroSection from '../../components/herosection'
import SectionHeader from '../../components/sectionHeader'
import CategorySection from '../../components/categorySection'
import FeatureBar from '../../components/featureBar' 
import ShippingIcon from '../../icons/shippingIcon'
import RefreshIcon from '../../icons/refreshIcon'
import SecureIcon from '../../icons/secureIcon'
import ReturnIcon from '../../icons/returnIcon'
import HeadPhoneIcon from '../../icons/headPhoneIcon'
import AdvertismentBar from '../../components/advertismentBar'

const features = [
    { icon:  <ShippingIcon />, text: 'Free Shipping Over $199' },
    { icon:  <RefreshIcon/> , text: '30 Days Money Back' },
    { icon:  <SecureIcon/> , text: '100% Secure Payment' },
    { icon:  <ReturnIcon/> , text: 'Free Product Return' },
    { icon:  <HeadPhoneIcon/> , text: '24/7 Online & Offline Support' },
  ];

const Home = () => {
  return (
   <Fragment>
    <HeroSection />
    {/* <CategorySection />
    <Section pt={"30"} pb={"30"}>
        <Container>
            <Row>
                <Col lg={12}>
                <FeatureBar  features={features} />
                </Col>
            </Row>
        </Container>
    </Section>
    
    <Section pt={"30"} pb={"30"}>
        <Container>
            <Row>
                <Col lg={12}>
                <AdvertismentBar  />
                </Col>
            </Row>
        </Container>
    </Section> */}

   </Fragment>
  )
}

export default Home