 
import { Fragment } from 'react';
import Header from './components/header';  
import Home from './pages/home';

function App() {
  return (
  <Fragment> 
    <Header/>  
    <Home/>
  </Fragment>
  );
}

export default App;
